const a="Piyush";
const b="Tiwary";
const c="Pandit";
const d="Mahi";

export default c;
export {a};
export {b};
export {d};