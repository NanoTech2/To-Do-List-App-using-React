import React , {useState} from 'react'

export default function TextForm(props) {
    //Arrow functions
    const handleUpClick = () =>{
        // console.log("Uppercase was clicked "+text);
        let newText=text.toUpperCase();
        setText(newText);
    }
    const handleLowClick = () =>{
        let newText=text.toLowerCase();
        setText(newText);
    }       
    const handleClearClick = () =>{
        let newText="";
        setText(newText);
    }    
    const handleCopy = () =>{
        var text=document.getElementById("myBox");
        text.select();
        navigator.clipboard.writeText(text.value);
    }

    const handleExtraSpaces = () =>{
        let newText=text.split(/[ ]+/);
        setText(newText.join(" "));
    }

    const handleTrim = () =>{
        let newText=text.trim();
        setText(newText);
    }  

    const handleCapitalizeFirstLetter =() =>{
        let newText=text.charAt(0).toUpperCase() + text.slice(1);
        setText(newText);
    }

    const handleOnChange = () =>{
        // console.log("On Change");
        setText(event.target.value);
    }
    const [text, setText] = useState('');
    //text="new text"; //Wrong to change the state
    //setText("new Text"); //Correct Way to change the state
    // let count=text.split(" ").length;
    return (
        <>
        <div className="container" style={{color : props.mode == 'light' ? 'black':'white'}}>
            <h1>{props.heading}</h1>
            <div className="mb-3">
                <textarea className="form-control" value={text} onChange={handleOnChange} style={{backgroundColor: props.mode == 'light'?'white':'grey' ,
            color:props.mode == 'light' ? 'black':'white'}} placeholder="Enter your text" id="myBox" rows="8"></textarea>
            </div>
            <button className="btn btn-primary mx-3" onClick={handleUpClick}>Convert to Uppercase</button>
            <button className="btn btn-primary mx-3" onClick={handleLowClick}>Convert to Lowercase</button>
            <button className="btn btn-primary mx-3" onClick={handleClearClick}>Clear text</button>
            <button className="btn btn-primary mx-3" onClick={handleCopy}>Copy text</button>
            <button className="btn btn-primary mx-3" onClick={handleExtraSpaces}>Remove Extra Spaces</button>
            <button className="btn btn-primary mx-3" onClick={handleTrim}>Trim Text</button>
            <button className="btn btn-primary mx-3 my-3" onClick={handleCapitalizeFirstLetter}>Capitalize First Letter</button>
        </div>
        <div className="container" style={{color : props.mode == 'light' ? 'black':'white'}}>
            <h2 className="my-3">Your Text summary</h2>
            <p>{text.split(" ").length} words and {text.length} characters</p>
            <p>{text.split(" ").length*0.008} Minutes to read above text</p>
            <h2>Preview</h2>
            <p>{text.length>0?text:"Enter something in the textbox to preview it here"}</p>
        </div>
        </>
    )
}
